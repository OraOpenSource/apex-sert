@cfg/sv_sec_data.sql
@cfg/sv_sec_version_dml.sql
@cfg/sv_sec_rule_type.sql
@cfg/sv_sec_rule_source.sql
@cfg/sv_sec_htp_procs.sql
@cfg/sv_sec_impact.sql
@cfg/sv_sec_colors_dml.sql
@cfg/sv_sec_pref_defaults_dml.sql
@cfg/sv_sec_snippets.sql "^admin_email_address"
--@cfg/sv_sec_info_fix_pdf.sql
@cfg/sv_sec_css_data.sql
@cfg/sv_sert_eval_job.sql "^parse_as_user"  -- Needs to be last b/c of schema change