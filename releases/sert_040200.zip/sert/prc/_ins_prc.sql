PROMPT == LAUNCH_ESERT
@prc/launch_sert.pls
/
SHOW ERRORS 
/