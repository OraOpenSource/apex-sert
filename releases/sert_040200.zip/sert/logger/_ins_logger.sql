PROMPT == LOGGER
--@logger/create_user.sql
@logger/logger_install.sql
