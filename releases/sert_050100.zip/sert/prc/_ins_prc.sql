PROMPT == LAUNCH_APEX-SERT
@prc/launch_sert.pls
/
SHOW ERRORS 
/

PROMPT == HTPC
@prc/htpc.pls
/
SHOW ERRORS 
/
